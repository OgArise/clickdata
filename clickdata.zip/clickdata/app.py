import os
from flask import Flask, render_template, request, redirect, url_for, flash, g, jsonify
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, URLField, IntegerField
from wtforms.validators import DataRequired, Length, EqualTo, URL, NumberRange
import secrets
from datetime import datetime
import sqlite3
from user_agents import parse
import geoip2.database

app = Flask(__name__, template_folder=os.path.dirname(os.path.abspath(__file__)))
app.config['GEOIP_DATABASE'] = os.path.join(app.root_path, 'GeoLite2-City.mmdb')
app.config['SECRET_KEY'] = os.urandom(24)
app.config['DATABASE'] = os.path.join(app.root_path, 'clickdata.db')

# Check if GeoLite2-City.mmdb exists, if not, disable geoip functionality
if not os.path.exists(app.config['GEOIP_DATABASE']):
    app.config['GEOIP_ENABLED'] = False
    print("Warning: GeoLite2-City.mmdb not found. Geolocation features will be disabled.")
else:
    app.config['GEOIP_ENABLED'] = True

login_manager = LoginManager(app)
login_manager.login_view = 'login'

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(app.config['DATABASE'])
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

class User(UserMixin):
    def __init__(self, id, username, password_hash):
        self.id = id
        self.username = username
        self.password_hash = password_hash

    @staticmethod
    def get(user_id):
        db = get_db()
        user_data = db.execute('SELECT * FROM users WHERE id = ?', (user_id,)).fetchone()
        if user_data:
            return User(user_data['id'], user_data['username'], user_data['password_hash'])
        return None

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=4, max=80)])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=8)])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Register')

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class LinkForm(FlaskForm):
    url = URLField('URL', validators=[DataRequired(), URL()])
    name = StringField('Link Name', validators=[DataRequired(), Length(max=100)])
    submit = SubmitField('Create Short Link')

class SearchForm(FlaskForm):
    query = StringField('Search', validators=[DataRequired()])
    submit = SubmitField('Search')

class PaginationForm(FlaskForm):
    per_page = IntegerField('Links per page', validators=[NumberRange(min=10, max=100)], default=20)
    submit = SubmitField('Update')

@login_manager.user_loader
def load_user(user_id):
    return User.get(user_id)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        db = get_db()
        existing_user = db.execute('SELECT * FROM users WHERE username = ?', (form.username.data,)).fetchone()
        if existing_user:
            flash('Username already exists. Please choose a different one.', 'danger')
        else:
            hashed_password = generate_password_hash(form.password.data)
            db.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', (form.username.data, hashed_password))
            db.commit()
            flash('Your account has been created! You are now able to log in', 'success')
            return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        db = get_db()
        user_data = db.execute('SELECT * FROM users WHERE username = ?', (form.username.data,)).fetchone()
        if user_data and check_password_hash(user_data['password_hash'], form.password.data):
            user = User(user_data['id'], user_data['username'], user_data['password_hash'])
            login_user(user)
            flash('Logged in successfully.', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Login unsuccessful. Please check username and password', 'danger')
    return render_template('login.html', title='Login', form=form)

@app.route('/dashboard', methods=['GET', 'POST'])
@login_required
def dashboard():
    link_form = LinkForm()
    search_form = SearchForm()
    pagination_form = PaginationForm()
    
    if link_form.validate_on_submit():
        short_code = secrets.token_urlsafe(6)
        db = get_db()
        db.execute('INSERT INTO links (original_url, short_code, user_id, name) VALUES (?, ?, ?, ?)',
                   (link_form.url.data, short_code, current_user.id, link_form.name.data))
        db.commit()
        flash('Your short link has been created!', 'success')
        return redirect(url_for('dashboard'))
    
    db = get_db()
    per_page = request.args.get('per_page', 20, type=int)
    page = request.args.get('page', 1, type=int)
    search_query = request.args.get('query', '')
    
    if search_query:
        links = db.execute('SELECT * FROM links WHERE user_id = ? AND name LIKE ?', 
                           (current_user.id, f'%{search_query}%')).fetchall()
    else:
        links = db.execute('SELECT * FROM links WHERE user_id = ?', (current_user.id,)).fetchall()
    
    total_links = len(links)
    start = (page - 1) * per_page
    end = start + per_page
    paginated_links = links[start:end]
    
    total_pages = (total_links + per_page - 1) // per_page
    pagination = {
        'page': page,
        'per_page': per_page,
        'total_pages': total_pages,
        'total_links': total_links
    }
    
    return render_template('dashboard.html', title='Dashboard', link_form=link_form, 
                           search_form=search_form, pagination_form=pagination_form,
                           links=paginated_links, pagination=pagination)

@app.route('/search')
@login_required
def search():
    query = request.args.get('query', '')
    db = get_db()
    links = db.execute('SELECT * FROM links WHERE user_id = ? AND name LIKE ?', 
                       (current_user.id, f'%{query}%')).fetchall()
    return jsonify([dict(link) for link in links])

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))

@app.route('/user_stats')
def user_stats():
    # This is a placeholder. Implement the actual user stats logic here.
    return "User stats page is under construction."

@app.route('/<short_code>')
def redirect_link(short_code):
    db = get_db()
    link = db.execute('SELECT * FROM links WHERE short_code = ?', (short_code,)).fetchone()
    if link:
        user_agent = parse(request.user_agent.string)
        db.execute('''INSERT INTO clicks 
                      (link_id, timestamp, ip_address, user_agent, referrer, device, os, browser)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                   (link['id'], datetime.utcnow(), request.remote_addr, request.user_agent.string,
                    request.referrer, user_agent.device.family, user_agent.os.family, user_agent.browser.family))
        db.commit()
        return redirect(link['original_url'])
    return "Link not found", 404

@app.route('/stats/<int:link_id>')
@login_required
def link_stats(link_id):
    db = get_db()
    link = db.execute('SELECT * FROM links WHERE id = ? AND user_id = ?', (link_id, current_user.id)).fetchone()
    if not link:
        flash('You do not have permission to view these stats.', 'danger')
        return redirect(url_for('dashboard'))
    
    clicks = db.execute('SELECT * FROM clicks WHERE link_id = ?', (link_id,)).fetchall()
    
    total_clicks = len(clicks)
    unique_visitors = len(set([click['ip_address'] for click in clicks]))
    devices = {}
    browsers = {}
    os_stats = {}
    countries = {}
    cities = {}
    
    if app.config['GEOIP_ENABLED']:
        reader = geoip2.database.Reader(app.config['GEOIP_DATABASE'])
    
    for click in clicks:
        devices[click['device']] = devices.get(click['device'], 0) + 1
        browsers[click['browser']] = browsers.get(click['browser'], 0) + 1
        os_stats[click['os']] = os_stats.get(click['os'], 0) + 1
        
        if app.config['GEOIP_ENABLED']:
            try:
                response = reader.city(click['ip_address'])
                country = response.country.name
                city = response.city.name
                countries[country] = countries.get(country, 0) + 1
                cities[city] = cities.get(city, 0) + 1
            except:
                countries['Unknown'] = countries.get('Unknown', 0) + 1
                cities['Unknown'] = cities.get('Unknown', 0) + 1
        else:
            countries['Geolocation Disabled'] = countries.get('Geolocation Disabled', 0) + 1
            cities['Geolocation Disabled'] = cities.get('Geolocation Disabled', 0) + 1
    
    if app.config['GEOIP_ENABLED']:
        reader.close()
    
    return render_template('stats.html', title='Link Stats', link=link, clicks=clicks,
                           total_clicks=total_clicks, unique_visitors=unique_visitors,
                           devices=devices, browsers=browsers, os_stats=os_stats,
                           countries=countries, cities=cities)

def init_db():
    with app.app_context():
        db = get_db()
        with app.open_resource('schema.sql', mode='r') as f:
            db.cursor().executescript(f.read())
        db.commit()

init_db()

if __name__ == '__main__':
    app.run(debug=True)
